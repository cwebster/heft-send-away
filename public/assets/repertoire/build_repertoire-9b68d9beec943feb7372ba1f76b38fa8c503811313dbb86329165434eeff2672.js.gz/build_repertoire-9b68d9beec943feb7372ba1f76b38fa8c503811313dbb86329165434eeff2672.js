$(document).ready(function(){
  //Dropdown menu - select2 plug-in
  $('#build_repertoire').DataTable();

});
